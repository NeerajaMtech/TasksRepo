<?php

namespace App\Http\Controllers;

use App\Models\WeatherAPIData;
use Log;

class WeatherController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        //
    }

    /**
     * Get Weather data using API
     * @return string
     */
    public function getWeatherAPIData() {
        $response = ["success" => false];
        // Get lastest data
        $latestRecord = WeatherAPIData::latest()->first();

        if ($latestRecord) {
            $lastDate = date("d-m-Y h:i:s a", strtotime($latestRecord->created_at));
            $nextDate = date("d-m-Y h:i:s a", strtotime("+1 hour", strtotime($latestRecord->created_at)));

            if (time() < strtotime($nextDate)) {
                $response['error'] = "Data has already been updated in the last one hour. Please try after : " . $nextDate;

                return $response;
            }
        }
        $cityName = env('CITY_NAME');
        $apiData  = $this->fetchWeatherData($cityName);
        if ($apiData['isError']) {
            Log::error("Weather API Error while getting data" . $apiData['data']);

            return $response;
        }
        WeatherAPIData::create(['city' => $cityName, 'api_response' => json_encode($apiData['data'])]);
        $response = ["success" => true, "message" => "Weather data stored successfully into DB"];

        return $response;
    }

    /**
     * Read config data and fetch weather data
     *
     * @return data
     */
    public function fetchWeatherData($city) {
        $baseUrl        = env('WEATHER_API_URL');
        $key            = env('API_KEY');
        $openWeatherURL = $baseUrl . "?q=" . $city . "&APPID=" . $key;

        return $this->fetchData($openWeatherURL);
    }

    /**
     * Get Fetch data from openweather URL
     * @param type $openWeatherURL
     * @return type
     */
    public function fetchData($openWeatherURL) {
        try {
            $isError    = FALSE;
            $client     = new \GuzzleHttp\Client(['http_errors' => false]);
            $response   = $client->request('GET', $openWeatherURL);
            $resContent = $response->getBody()->getContents();
        } catch (Guzzle\Http\Exception\ClientErrorResponseException $e) {
            $isError    = TRUE;
            $resContent = $e->getMessage();
        }
        return ['isError' => $isError, 'data' => $resContent];
    }

}
