<?php 

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WeatherAPIData extends Model
{
    protected $table = "weatherapidata";
    protected $guarded = ['id'];

    public $timestamps = true;    
}
